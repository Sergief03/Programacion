package clases;

public enum Palo {
    OROS,COPAS,ESPADAS,BASTOS;
}
