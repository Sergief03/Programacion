package clases;

public enum TipoJugador {
    PERSONA, ORDENADOR;
}
