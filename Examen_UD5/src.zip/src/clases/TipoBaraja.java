package clases;

public enum TipoBaraja {
    PARCIAL,COMPLETA;

}
