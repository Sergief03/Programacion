package test;

import clases.SieteYMedia;

public class SieteYMediaPrueba {
    public static void main(String[] args) {
        SieteYMedia sieteYMedia=new SieteYMedia();
        sieteYMedia.jugar();
    }
}
