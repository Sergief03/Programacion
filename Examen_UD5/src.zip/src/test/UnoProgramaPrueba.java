package test;

import clases.ElUnoMaldito;

public class UnoProgramaPrueba {
    public static void main(String[] args) {
        ElUnoMaldito elUnoMaldito=new ElUnoMaldito();
        elUnoMaldito.jugar();
    }
}
