package tema5.superejercicio.ejercicio55;

public enum TipoCatalogo {
    ARCHIVO,BD_MYSQL,BD_MOGODB,API_REST
}
