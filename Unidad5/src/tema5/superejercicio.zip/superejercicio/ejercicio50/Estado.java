package tema5.superejercicio.ejercicio50;

public enum Estado {
    SIN_RECIBIR,RECIBIDO,RECOGIDO
}
