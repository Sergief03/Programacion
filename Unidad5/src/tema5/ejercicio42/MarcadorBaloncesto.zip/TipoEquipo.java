package tema5.ejercicio42;

public enum TipoEquipo {
    LOCAL, VISITANTE;
}
