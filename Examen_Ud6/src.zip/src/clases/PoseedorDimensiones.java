package clases;

public interface PoseedorDimensiones extends Dibujable {
    public abstract int getAltura();
    public abstract int getAnchura();
}
